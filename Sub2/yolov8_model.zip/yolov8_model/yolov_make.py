import ultralytics

ultralytics.checks()

from ultralytics import YOLO

model = YOLO("yolov8n.pt")
